const express = require('express');
const vendorLogin = require('../Controllers/logincontroller')

const router = express.Router();

// Login Page
router.get('/login', vendorLogin);

// Login Logic
router.post('/login', vendorLogin);

// Logout
router.get('/logout', vendorLogin);

module.exports = router;
